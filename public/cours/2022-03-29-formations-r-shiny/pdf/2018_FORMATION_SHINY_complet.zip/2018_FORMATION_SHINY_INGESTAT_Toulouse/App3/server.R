#
# Correction de l'exercice 2
# 

library(shiny)

dt<-read.csv("../datasncf_prepare.csv")

# Define server logic required to draw a histogram
shinyServer(function(input, output) {
  
 dtannee <- reactive({
     subset(dt, dt$Annee==input$annee)
 })
    
 observe({
     print(input$annee)
 })
    
  output$distPlot <- renderPlot({
    
    
    x    <- dtannee()[, "Nb_Programmes"] 
    y    <- dtannee()[, input$vary] 
    
    # Nuage de points x, y
    plot(x, y, main=paste0(input$titre, ", ", input$annee))
  })
  
  
  output$matable <- renderDataTable({
      dtannee()
  })
  
  
  
  
})

# Question : 
# Creer un nouvel onglet dans l'interface, dans lequel on affichera les donnees de l'annee selectionnee
# tips : tabPanel, tableOutput

