#
# Correction de l'exercice 2
#

library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(
  
  # Application title
  titlePanel("Ma seconde application"),
  
  # Sidebar with a slider input for number of bins 
  sidebarLayout(
    sidebarPanel(
       sliderInput("annee", "Annee : ", min=2011, max=2017, value=2012, animate=T),
       textInput("titre", "Titre :", "mon super titre"),
       selectInput("vary", "Variable y", choices = c("Nb_Annules", "Nb_Retard"))
    ),
    
    # Show a plot of the generated distribution
    mainPanel(
        "Onglets plot et table",
        tabsetPanel(
            tabPanel("Plot", 
                     plotOutput("distPlot")
                     ),
            tabPanel("Table", dataTableOutput("matable"))
        )
       
    )
  )
))
