#
# Correction de l'exercice 3
# 

library(shiny)

dt<-read.csv("../datasncf_prepare.csv")

# Define server logic required to draw a histogram
shinyServer(function(input, output) {
  
  output$distPlot <- renderPlot({
    dtannee<-subset(dt, dt$Annee==input$annee)
    x    <- dtannee[, "Nb_Programmes"] 
    y    <- dtannee[, input$vary] 
    
    # Nuage de points x, y
    plot(x, y, main=paste0(input$titre, ", ", input$annee))
  })
  
  output$tableannee <- renderTable({
    dtannee<-subset(dt, dt$Annee==input$annee)
    dtannee
  })
})

# Question : 
# Modifier le programme pour ne "creer" qu'une fois le sous-jeu de donnees selectionne.
# Tip: Utiliser l'environnement "reactive"


