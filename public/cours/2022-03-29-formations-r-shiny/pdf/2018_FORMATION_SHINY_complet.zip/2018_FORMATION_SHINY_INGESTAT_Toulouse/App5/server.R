#
# Correction de l'exercice 4
# 

library(shiny)

dt<-read.csv("../datasncf_prepare.csv")

# Define server logic required to draw a histogram
shinyServer(function(input, output) {
  
  dtannee<-reactive({
    subset(dt, dt$Annee==input$annee)
  })
  
  output$distPlot <- renderPlot({
    x    <- dtannee()[, "Nb_Programmes"] 
    y    <- dtannee()[, input$vary] 
    
    # Nuage de points x, y
    plot(x, y, main=paste0(input$titre, ", ", input$annee))
  })
  
  output$tableannee <- renderTable({
    dtannee()
  })
})


# Question : 
# Utiliser l'environnement "observe" pour charger automatiquement les noms des colonnes dans
# le selectInput pour choisir la variable y.

# Tip: observe,  colnames, updateSelectInput
# Attention a l'ecriture du shinyServer(function(){})
                                      


