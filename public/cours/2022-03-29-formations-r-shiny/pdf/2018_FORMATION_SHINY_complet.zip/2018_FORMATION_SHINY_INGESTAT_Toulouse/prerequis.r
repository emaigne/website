#### Vérifiez que vous arrivez bien à lire les données

datatrain<-read.csv("datasncf_prepare.csv")
summary(datatrain)
View(datatrain)

#### verifiez que le package shiny soit bien installé
library(shiny)

# Sinon faire
# install.packages("shiny")


