# On vide l'environnement
rm(list=ls())

# Definition du répertoire de travail (inutile si on ouvre un fichier projet)
# setwd('C:/Users/emaigne/FORMATION_SHINY_INGESTAT/')

# Lecture des donnees 

datatgv<-read.csv("DATA_SOURCE/regularite-mensuelle-tgv.csv", sep=";", encoding = "UTF-8")
datainterc<-read.csv("DATA_SOURCE/regularite-mensuelle-intercites.csv", sep=";", encoding = "UTF-8")

# https://ressources.data.sncf.com/explore/embed/dataset/regularite-mensuelle-intercites/table
# https://ressources.data.sncf.com/explore/embed/dataset/regularite-mensuelle-tgv/table


# Preparation des donnees : on cree le type de ligne, l'annee et on ne garde que quelques colonnes

datatgv$Annee <- substr(datatgv$Date,1,4)
datainterc$Annee <- substr(datainterc$Date,1,4)

datatgv$Typeligne <- "TGV"
datainterc$Typeligne <- "Intercité"

nomcols <- c("Annee", "Départ", "Arrivée", "Nombre.de.trains.programmés",  
             "Nombre.de.trains.annulés", "Nombre.de.trains.en.retard.à.l.arrivée", "Typeligne")
datatgv<-datatgv[, nomcols ]
datainterc<-datainterc[, nomcols ]

datatrain<-rbind(datainterc, datatgv)
rm(datatgv, datainterc)

# Création de noms de colonnes plus simples à manipuler
nomcols_new <- c("Annee", "Depart", "Arrivee", "Nb_Programmes", "Nb_Annules", "Nb_Retard", "Typeligne")
colnames(datatrain)<-nomcols_new

summary(datatrain)
datatrain<-datatrain[is.na(datatrain$Nb_Programmes)==F & is.na(datatrain$Nb_Annules)==F & is.na(datatrain$Nb_Retard)==F,]

# On crée un jeu de données par année plutôt que par mois (on somme par an, type de ligne, départ, arrivée)
datatrain<-aggregate(. ~ Typeligne + Annee + Depart + Arrivee, data=datatrain, FUN=sum)

# calcul de 2 variables
datatrain$Tx_Regularite <- (datatrain$Nb_Programmes - datatrain$Nb_Retard) / datatrain$Nb_Programmes
datatrain$Tx_Circulation <- (datatrain$Nb_Programmes - datatrain$Nb_Annules) / datatrain$Nb_Programmes
datatrain$Annee<-as.numeric(datatrain$Annee)

# Création d'une variable sur les lignes PARIS PROVINCE ou PROVINCE PARIS OU PROVINCE PROVINCE

datatrain$DepDest<-ifelse(grepl("PARIS", datatrain$Depart)>0,"PARIS", "PROVINCE")
datatrain$DepDest<-ifelse(grepl("PARIS", datatrain$Arrivee)>0,paste(datatrain$DepDest, "PARIS", sep="-"), paste(datatrain$DepDest, "PROVINCE", sep="-"))

write.csv(datatrain, file="datasncf_prepare.csv", row.names = F)




# exemples de graphiques

plot(datatrain$Regularite ~ datatrain$Trains_programmes)
plot(Regularite ~ Trains_programmes, data=datatrain, main="Régularité des trains")
plot(Regularite ~ Trains_programmes, data=datatrain[datatrain$Annee==2011,], main="Régularité des trains")
plot(Regularite ~ Trains_programmes, data=datatrain[datatrain$Annee==2016,], main="Régularité des trains")


plot(Regularite ~ Trains_programmes, data=datatrain[datatrain$Annee==2011,], main="Régularité des trains, en 2011", 
     xlim=c(min(datatrain$Trains_programmes), max(datatrain$Trains_programmes)),
     ylim=c(min(datatrain$Regularite), max(datatrain$Regularite)))
plot(Regularite ~ Trains_programmes, data=datatrain[datatrain$Annee==2016,], main="Régularité des trains, en 2016", 
     xlim=c(min(datatrain$Trains_programmes), max(datatrain$Trains_programmes)),
     ylim=c(min(datatrain$Regularite), max(datatrain$Regularite)))


# création d'une variable locale année 

annee<-2011

plot(Regularite ~ Trains_programmes, data=datatrain[datatrain$Annee==annee,], 
     main=paste0("Régularité des trains, en ", annee), 
     xlim=c(min(datatrain$Trains_programmes), max(datatrain$Trains_programmes)),
     ylim=c(min(datatrain$Regularite), max(datatrain$Regularite)))


plot(Regularite ~ Trains_programmes, data=datatrain[datatrain$Annee==annee,], 
     main=paste0("Régularité des trains, en ", annee), 
     xlim=c(min(datatrain$Trains_programmes), max(datatrain$Trains_programmes)),
     ylim=c(min(datatrain$Regularite), max(datatrain$Regularite)),
     col=ifelse(Typeligne=="TGV", "red", "black"))
legend("bottomleft", legend=c("TGV", "Intercités"), col=c("red", "black"), lty=1, bty="n")


plot(datatrain[datatrain$Annee==annee,"Regularite"] ~ datatrain[datatrain$Annee==annee,"Trains_programmes"], 
     main=paste0("Régularité des trains, en ", annee), 
     xlim=c(min(datatrain[,"Trains_programmes"]), max(datatrain[,"Trains_programmes"])),
     ylim=c(min(datatrain[,"Regularite"]), max(datatrain[,"Regularite"])),
     col=ifelse(datatrain[datatrain$Annee==annee,"Typeligne"]=="TGV", "red", "black"))
legend("bottomleft", legend=c("TGV", "Intercités"), col=c("red", "black"), lty=1, bty="n")


plot(datatrain[datatrain$Annee==annee,"Regularite"] ~ datatrain[datatrain$Annee==annee,"Trains_programmes"], 
     main=paste0("Régularité des trains, en ", annee), 
     xlim=c(min(datatrain[,"Trains_programmes"]), max(datatrain[,"Trains_programmes"])),
     ylim=c(min(datatrain[,"Regularite"]), max(datatrain[,"Regularite"])),
     col=ifelse(datatrain[datatrain$Annee==annee,"Typeligne"]=="TGV", "red", "black"),
     xlab="Trains programmés",
     ylab="Regularité")
legend("bottomleft", legend=c("TGV", "Intercités"), col=c("red", "black"), lty=1, bty="n")



plot(datatrain[datatrain$Annee==annee,"Regularite"] ~ datatrain[datatrain$Annee==annee,"Trains_programmes"], 
     main=paste0("Régularité des trains, en ", annee), 
     xlim=c(min(datatrain[,"Trains_programmes"]), max(datatrain[,"Trains_programmes"])),
     ylim=c(min(datatrain[,"Regularite"]), max(datatrain[,"Regularite"])),
     col=as.factor(datatrain[datatrain$Annee==annee,"DepDest"]),
     xlab="Trains programmés",
     ylab="Regularité")
legend("bottomright", legend=unique(datatrain[datatrain$Annee==annee,"DepDest"]), col=as.factor(unique(datatrain[datatrain$Annee==annee,"DepDest"])), lty=1, bty="n")



annee<-2014

plot(datatrain[,"Regularite"] ~ datatrain[,"Trains_programmes"], 
     main="Régularité des trains"), 
     xlab="Trains programmés",
     ylab="Regularité")

dttemp<-subset(datatrain, Annee==annee)
plot(dttemp[,"Regularite"] ~ dttemp[,"Trains_programmes"], 
     main=paste0("Régularité des trains, en ", annee), 
     xlab="Trains programmés",
     ylab="Regularité")





