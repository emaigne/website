#
# Correction de l'exercice 1
# 

library(shiny)

dt<-read.csv("../datasncf_prepare.csv")

# Define server logic required to draw a histogram
shinyServer(function(input, output, session) {
   
    
observe({
    print("valeur input$choixannee")
    print(input$choixannee)
})    
    
    
updateSliderInput(session, "choixannee", 
                  min=min(dt$Annee, na.rm=T), 
                  max=max(dt$Annee, na.rm=T), 
                  value = c(min(dt$Annee, na.rm=T),max(dt$Annee, na.rm=T))
                  )
    

dtan <- reactive({
    dt2 <- subset(dt, Annee<=input$choixannee)
    dt2
})


  output$distPlot <- renderPlot({
    
    
    x    <- dtan()[, "Nb_Programmes"] 
    y    <- dtan()[, input$vary] 
    

    # Nuage de points x, y
    plot(x, y, main=input$titre)
  })
  
  

  
})

# Question : 
# Ajouter un slider pour choisir l'annee des donnees dans le graphique.
# tips : sliderInput  et subset

