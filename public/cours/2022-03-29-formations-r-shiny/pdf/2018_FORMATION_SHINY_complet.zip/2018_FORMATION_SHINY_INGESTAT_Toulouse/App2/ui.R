#
# Correction de l'exercice 1
#

library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(
  
  # Application title
  titlePanel("Ma premiere application"),
  
  # Sidebar with a slider input for number of bins 
  sidebarLayout(
    sidebarPanel(
       textInput("titre", "Titre :", "mon super titre"),
       selectInput("vary", "Variable y", choices = c("Nb_Annules", "Nb_Retard")),
       sliderInput("choixannee", "Choix de l'année", min=2011, max=2017, 
                   value=c(2011, 2014), sep="")
    ),
    
    # Show a plot of the generated distribution
    mainPanel(
       plotOutput("distPlot")
    )
  )
))
