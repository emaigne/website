#
# Correction de l'exercice 0
# 

library(shiny)


# Les applications appellent les donnees depuis l'emplacement des fichiers server et ui. 
dt<-read.csv("../datasncf_prepare.csv")

# Define server logic required to draw a histogram
shinyServer(function(input, output) {
   
  output$distPlot <- renderPlot({
    
    # Etre sur d'appeler la bonne variable du fichier dt : (Equivalent a dt$NB_Programmes, 
    # mais dans shiny on aura besoin de travailler avec des caractères)
    x    <- dt[, "Nb_Programmes"] 
    y    <- dt[, "Nb_Annules"] 
    
    # bins <- seq(min(x), max(x), length.out = input$bins + 1)
    
    # Nuage de points x, y
    plot(x, y)
  })
  
})

# Question : 
# Modifier l'application pour permettre a l'utilisateur de changer le titre du graphique.
# tips : textInput et plot(x, y, main="mon super titre")