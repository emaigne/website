#
# Correction de l'exercice 5
#

library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(
  
  # Application title
  titlePanel("Ma cinquieme application"),
  
  # Sidebar with a slider input for number of bins 
  sidebarLayout(
    sidebarPanel(
       sliderInput("annee", "Annee : ", min=2011, max=2017, value=2011, animate=T),
       textInput("titre", "Titre :", "mon super titre"),
       selectInput("vary", "Variable y", choices = NULL)
    ),
    
    # Show a plot of the generated distribution
    mainPanel(
      tabsetPanel(
        tabPanel("Plot", plotOutput("distPlot")),
        tabPanel("Table", tableOutput("tableannee"))
      )
    )
    
  )
))
