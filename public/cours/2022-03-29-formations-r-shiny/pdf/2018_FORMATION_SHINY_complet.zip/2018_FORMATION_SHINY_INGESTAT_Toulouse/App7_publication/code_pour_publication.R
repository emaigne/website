library(rsconnect)

# Je me connecte a mon compte sur https://www.shinyapps.io/

# Suivre les instructions sur la page : https://www.shinyapps.io/admin/#/dashboard
# 1 et 2 a ne faire que la premiere fois.

# Important !!! 
# Je m'assure que les donnees et les codes ui.R et server.R sont dasn le meme dossier. Sous-dossiers acceptes. 
# Fichiers css, js, ... acceptes dans un sous-dossier www

rsconnect::deployApp('//tls-dyn-nas/odr/emaigne/Documents/APPLIS_SHINY/INGE_STAT/CODES_FORMATION_SHINY/App7_publication')

# J'envoie le lien a des gens sympas : 
https://elisemaigne.shinyapps.io/app7_publication/
  
# Attention: c'est public!