#
# Mon application qui tournera en ligne (exo 5)
# 

library(shiny)

dt<-read.csv("datasncf_prepare.csv")

# Define server logic required to draw a histogram
shinyServer(function(input, output, session) {
  
  updateSelectInput(session, "vary", choices=colnames(dt), selected="Nb_Annules")
  
  dtannee<-reactive({
    subset(dt, dt$Annee==input$annee)
  })
  
  output$distPlot <- renderPlot({
    validate(
      need(input$vary %in% colnames(dt), 'Patientez...')
    )
    x    <- dtannee()[, "Nb_Programmes"] 
    y    <- dtannee()[, input$vary] 
    validate(
      need(is.numeric(y), 'La variable y doit etre numerique')
    )
    # Nuage de points x, y
    plot(x, y, main=paste0(input$titre, ", ", input$annee))
  })
  
  output$tableannee <- renderTable({
    dtannee()
  })
})





